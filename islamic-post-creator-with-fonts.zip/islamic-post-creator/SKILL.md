---
name: islamic-post-creator
description: Create Instagram-ready Islamic content (carousel slides + caption) for @ibnesaed in Urdu, Arabic or English from an ayah, hadith, seerah story or Islamic topic. Uses bundled Urdu/Arabic fonts, the IbneSaed maroon-gold palette and a 15-layout library, and builds a whole carousel in one command (JPG + PDF + contact sheet). Use whenever the user asks for an Islamic post, carousel, seerat series, hadith/ayah post, Urdu Islamic content, or pastes slide text/images and says "make a carousel". Verifies sources unless the user says the text is already verified.
---

# Islamic Post Creator

Pipeline: capture intent → verify source (unless user already did) → pick layouts → ONE build command → one QA look → caption → deliver.
Goal: finish the whole carousel in one run, with minimal tool calls and light files.

## Step 1 — Intent (do not over-ask)
Infer from the message: content type, language, slide count (usually 3-10), account (default **@ibnesaed**). If the user supplied slide text and images, just build; do NOT ask clarifying questions. Images supplied "in sequence" map to slides in upload order (if filenames have timestamps, check they match the visual cue of each slide; reversed order happens).

## Step 2 — Source verification
Quran: quran.com. Hadith: sunnah.com (grade: sahih/hasan/da'if). Never present a weak/unfound hadith as authentic; tell the user. **If the user states the text is already verified, skip this step entirely** and use their text as given (only normalize digits/quotes/emojis; flag obvious typos such as غ vs گ in a single line at the end, do not silently change meaning).

## Step 3 — Design (brand-first)
- Default brand = IbneSaed: Deep Velvet Maroon `#2C0B0E`, Imperial Burgundy `#4A0E17`, Brushed Antique Gold `#C5A059` (highlight tint `#E3CB92`), Warm Alabaster `#E5DFD3`. Baked into the scripts; never add other brand colors, never pure black (shade with maroon tint 44,11,14). For a different account or an explicit user style, override the CSS variables in `scripts/build_carousel.py` BASE.
- Series continuation: reuse the same palette, fonts and layout family as earlier parts.
- Pick a DIFFERENT layout per slide from `templates/LAYOUTS.md` (15 layouts). Follow the retention playbook there: hook cover (image_text_hook or cover_stack), alternate dense/airy slides, one ivory_text slide mid-way, CTA outro last, one idea per slide, max ~45 words/slide, gold `[[highlight]]` on the emotional line, text never covers the photo's main subject.
- Fonts: ALWAYS the bundled fonts in `fonts/` (see `fonts/FONTS.md`). Do not download fonts. Urdu text only in fonts marked Urdu=yes; Arabic-only fonts (Zain, Ummi, Qalbi, KanYaMaKan, Mohawla, Cortoba) only for pure Arabic-letter words (e.g. محمد, الله, الأمين) via `{{CODE:text}}`. Jameel renders small: sizes are already tuned in layouts.
- No emojis anywhere (use the built-in SVG icons / ornaments). No fake or invented text, no human faces.

## Step 4 — Build (one command)
1. Write `spec.json`: `{"handle":"@IBNESAED","slides":[{"layout":"…","bg":"/abs/img.jpg", …fields}]}` (sample: `templates/example_spec.json`; fields per layout: `templates/LAYOUTS.md`).
   Markup: `[[gold]]`, `{{UM:محمد}}`, `\n`. Digits auto-convert to Urdu numerals (set `"urdu_digits": false` to disable). Use `pos` to move the photo so the subject stays visible.
2. Run: `python3 scripts/build_carousel.py spec.json /mnt/user-data/outputs/<name>`
   Output: `slide_01.jpg…` (1080×1350, ~250 KB), `carousel.pdf`, `sheet.jpg` (contact sheet). Frame, handle, counter, progress dots, swipe arrow are automatic.
   The spec is saved as `OUT_DIR/spec.json`. For later edits change only that field and run again with `--only 4,7` (rebuilds just those slides + PDF + sheet) instead of redesigning.
   Big photos: run `python3 scripts/prep_images.py <imgs> <dir>` first (max 1400px, saves time and credits).
3. View `sheet.jpg` ONCE. Fix only broken slides (text overflow, text over subject) by editing that slide's fields, then rebuild. Do not re-render repeatedly or polish what is fine.
4. Only if no layout fits: hand-write one HTML slide and render with `scripts/render_slide.py` (@font-face CSS must be the FIRST rule in `<style>`, otherwise fonts silently fail).

## Step 5 — Caption
Hook (first 2 lines), core reflection, full reference citation, call to action (save/share/comment درود), 5-15 hashtags mixing broad (#islam #seerah #quran) and niche; match earlier posts' style. Give caption as plain text in chat (Urdu unless asked otherwise).

## Step 6 — Deliver
Copy JPGs + `carousel.pdf` FLAT into `/mnt/user-data/outputs/` (no subfolders, no heavy 2x PNGs, no zip unless asked) and `present_files`. If the user reports files not opening, re-send as PDF. End with 2-4 lines max: what was built, any text flagged.

## Reference files
`fonts/FONTS.md` (font capabilities) · `templates/LAYOUTS.md` (layouts + retention playbook) · `templates/PALETTE.md` · `templates/example_spec.json` · `references/typography.md` · `references/design-system-tokens.md`.
