# Bundled fonts (use these FIRST, never download if present)
Load with @font-face from the skill's fonts/ folder, font-weight "100 900" (prevents faux bold).
| File | Urdu | Arabic | English | Use |
|---|---|---|---|---|
| Jameel_Noori_Nastaleeq_Regular.ttf | yes | yes | yes | Urdu body (render ~1.4x larger, it runs small) |
| Jameel_Noori_Nastaleeq_Kasheeda_-__UrduFonts_com_.ttf | yes | yes | yes | Urdu display titles (stretched) |
| Kinafah-Regular.otf | yes | yes | no | Big Urdu/Arabic headlines |
| CoconNextArabic-Light.ttf | yes | yes | yes | Thin headline lines (initial ہ looks like م: avoid words starting with ہ) |
| Elgharib-KFGQPCHafsV3-Taweel.ttf | partial (breaks) | yes | no | Quran ayah / pure Arabic only |
| ZAIN_mob_variable_200_/400_/600.ttf | NO | yes | no | Arabic-only words |
| zainmobileswashes-VF.ttf | NO | yes | no | Arabic-only swash display words |
| Ummi-Regular.ttf, Qalbi.otf | NO | yes | no | Arabic-only words (محمد, احمد) |
| KanYaMaKan-Regular.ttf | NO | yes | yes | Arabic-only words, Latin text |
Rule: fonts marked NO cannot render ٹ ی ہ گ; use only for pure Arabic-letter strings.
Missing glyph fallback: Jameel Noori. ﷺ: Jameel draws full calligraphy, set it small (~0.5em).

## Added later
| File | code | Urdu | Arabic | English | Use |
|---|---|---|---|---|---|
| DecoType_Thuluth_Regular.ttf | DT | yes | yes | no | Thuluth calligraphy headlines (no ﷺ glyph) |
| MadaniArabicDEMO-Regular.otf | MD | yes | yes | yes | Modern Arabic/Urdu/Latin display (DEMO: test glyphs) |
| MohawlaTypeface-Regular.otf | MH | NO | yes | no | Arabic-only display words |
| ae_Cortoba_-__UrduFonts_com_.ttf | CT | NO | yes | yes | Arabic-only words, Latin text |
In build_carousel.py/layouts.py use the code in font-family or inline as {{DT:الله}}.
