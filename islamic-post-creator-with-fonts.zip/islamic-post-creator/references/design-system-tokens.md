# IbneSaed default tokens (use these unless the user names another style)
--obs #2C0B0E | --mar #4A0E17 | --gold #C5A059 | --gold2 #E3CB92 | --cream #E5DFD3 ; radius 0 (sharp), hairline gold frame, 1080x1350.

# Defining a Design System Per Post

Since the visual style varies per post (not fixed), define a small token set at the top of the first slide's HTML (or in a shared `<style>` block reused across all slide files) so every slide in the carousel stays visually consistent.

## Minimum token set

```css
:root {
  --bg: #0d1117;          /* base background */
  --accent: #7a1f2b;       /* primary accent — maroon, gold, green, etc. */
  --text-primary: #f5f0e6; /* main readable text */
  --text-secondary: #9a9284; /* citations, captions, muted labels */
  --font-arabic: 'Amiri', serif;
  --font-urdu: 'Noto Nastaliq Urdu', serif;
  --font-latin: 'Inter', sans-serif;
  --radius: 12px;
  --slide-w: 1080px;
  --slide-h: 1350px;
}
```

## Three example directions (offer when the user hasn't specified)

**1. Reverent Classic**
- `--bg: #0f2818` (deep green), `--accent: #c9a86a` (gold), Amiri for Arabic, subtle geometric star-pattern border (SVG, low opacity)

**2. Modern Minimal**
- `--bg: #fafaf7` (warm off-white) or `--bg: #17181c` (charcoal) — pick light or dark once, generous margins, one accent color used sparingly, no decorative borders

**3. Tech Noir Protocol** (HMA's existing system, reuse if continuing that series)
- `--bg: #0a0908` (obsidian), `--accent: #6b1f2e` (maroon), Amiri/KFGQPC Uthmanic Script for Arabic, sharp edges (radius 0-4px), thin hairline dividers

## Slide anatomy (typical hadith/ayah carousel)

1. **Hook/title slide** — short, bold, sets up the theme
2. **Arabic text slide(s)** — the ayah/hadith in Arabic, centered, generous size
3. **Translation slide** — Urdu or English translation
4. **Reflection/context slide(s)** — brief explanation, 1 idea per slide
5. **Reference/citation slide** — full source citation + authenticity grade, smaller text, can be denser than other slides
6. **CTA/outro slide** — save/share prompt, account handle

Keep consistent margins, header treatment, and footer (page number or handle) across all slides using the same token set.
