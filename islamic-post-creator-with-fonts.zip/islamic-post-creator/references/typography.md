# Typography (bundled fonts first)
All fonts are in `fonts/` and registered by `scripts/build_carousel.py` (codes: JN Jameel Noori Regular, JK Jameel Kasheeda, KF Kinafah, CC Cocon Next Arabic Light, EG Elgharib, ZS Zain Swashes, Z4 Zain 400, DT DecoType Thuluth, MD Madani Arabic DEMO, MH Mohawla, CT Cortoba, UM Ummi, QB Qalbi, KM Kan Ya Ma Kan). Capabilities: `fonts/FONTS.md`. Never download fonts when these exist.

## Roles
- Urdu body: JN (renders small, use ~52-56px at 1080 width). Urdu display: JK or KF. Thin elegant lines: CC (avoid words starting with ہ). Calligraphy: DT.
- Arabic-only display words (محمد, الله, الأمين): ZS / UM / QB / MH, inline with `{{CODE:text}}`. Quranic ayah in Arabic: EG or Amiri-style Uthmanic.
- Latin (handle, counters): KM or CT.

## Rules
1. @font-face CSS must be the FIRST thing in the `<style>` block (a rule before `@import` makes it be ignored; fonts then silently fall back).
2. Line-height: Nastaliq (Jameel) 1.4-1.5 at large size, titles 1.45; nothing with `overflow:hidden` near text (loops get clipped).
3. RTL: `dir="rtl"` on the slide; mixed Latin/numbers wrapped in `dir="ltr"`.
4. ﷺ in Jameel draws full calligraphy: set it ~0.5em (class `.sw`, automatic in builder).
5. Quote marks: use “ ” and ‘ ’; Elgharib has no curly quotes and breaks Urdu letters, so never use it for Urdu.
6. Prefer right-aligned (RTL) short text; justify only long paragraphs.
7. Digits: Urdu numerals (۰۱۲۳۴۵۶۷۸۹) by default; Quran ayah markers Eastern Arabic; citations like 2:286 may stay Western. Be consistent in one post.
8. Playwright must wait for `document.fonts.ready` (builder does).
