#!/usr/bin/env python3
"""One-shot carousel builder.  python3 build_carousel.py spec.json OUT_DIR [--png]
Rebuild only some slides after editing spec: add `--only 4,7` (keeps the other JPGs, re-makes PDF + sheet). Spec is saved as OUT_DIR/spec.json.
Spec: {"handle":"@IBNESAED","slides":[{"layout":"cover_stack","bg":"/abs/img.jpg", ...layout fields...}, ...]}
Outputs OUT_DIR/slide_01.jpg ... + carousel.pdf + sheet.jpg (contact sheet for one-look QA). Western digits become Urdu numerals unless spec has "urdu_digits": false. See templates/LAYOUTS.md for every layout's fields."""
import json, sys, pathlib, re
from PIL import Image
from playwright.sync_api import sync_playwright
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from layouts import LAYOUTS

HERE = pathlib.Path(__file__).resolve().parent
FD = (HERE.parent / 'fonts')
FILES = {'JN':'Jameel_Noori_Nastaleeq_Regular.ttf','JK':'Jameel_Noori_Nastaleeq_Kasheeda_-__UrduFonts_com_.ttf','KF':'Kinafah-Regular.otf',
 'CC':'CoconNextArabic-Light.ttf','EG':'Elgharib-KFGQPCHafsV3-Taweel.ttf','ZS':'zainmobileswashes-VF.ttf','Z4':'ZAIN_mob_variable_400_.ttf',
 'DT':'DecoType_Thuluth_Regular.ttf','MH':'MohawlaTypeface-Regular.otf','MD':'MadaniArabicDEMO-Regular.otf','CT':'ae_Cortoba_-__UrduFonts_com_.ttf','UM':'Ummi-Regular.ttf','QB':'Qalbi.otf','KM':'KanYaMaKan-Regular.ttf'}
def fontcss():
    out = ''
    for k, f in FILES.items():
        p = FD / f
        if p.exists(): out += f"@font-face{{font-family:'{k}';font-weight:100 900;src:url({p.as_uri()});}}\n"
    return out   # MUST be first in the <style> block

BASE = """
:root{--obs:#2C0B0E;--gold:#C5A059;--gold2:#E3CB92;--cream:#E5DFD3;--mar:#4A0E17}
*{margin:0;padding:0;box-sizing:border-box}html,body{width:1080px;height:1350px;background:#2C0B0E}
.slide{width:1080px;height:1350px;position:relative;overflow:hidden;direction:rtl;color:var(--cream);background:var(--obs);word-spacing:.2em}
.bg{position:absolute;inset:0;background-repeat:no-repeat}.ov{position:absolute;inset:0}.abs{position:absolute}
.g2{color:var(--gold2)}
.sw{font-family:'JN',serif!important;font-size:.5em;line-height:1}
.hdr{position:absolute;top:64px;left:100px;right:100px;display:flex;justify-content:space-between;direction:ltr;font-family:'KM',sans-serif;font-size:22px;letter-spacing:.28em;color:var(--gold);opacity:.9;z-index:9}
.hline{position:absolute;top:110px;left:100px;right:100px;height:1px;background:linear-gradient(90deg,transparent,rgba(197,160,89,.55),transparent);z-index:9}
.swipe{position:absolute;bottom:66px;left:100px;direction:ltr;z-index:9}.swipe svg{width:70px;height:24px}
.dots{position:absolute;bottom:76px;left:0;right:0;display:flex;justify-content:center;gap:8px;z-index:9}.dots i{display:block;width:10px;height:4px;background:rgba(197,160,89,.35)}.dots i.on{width:38px;background:var(--gold)}
.frame{position:absolute;inset:30px;border:1px solid rgba(197,160,89,.6);z-index:8;pointer-events:none}
.frame2{position:absolute;inset:41px;border:1px solid rgba(197,160,89,.22);z-index:8;pointer-events:none}
.dm{position:absolute;width:12px;height:12px;background:var(--gold);transform:rotate(45deg);z-index:9}
.vig{background:radial-gradient(ellipse at 50% 45%,rgba(0,0,0,0) 48%,rgba(0,0,0,.55) 100%)}
.kick{display:flex;align-items:center;gap:20px;font-family:'KF','JN',serif;font-size:34px;line-height:1.6;color:var(--gold)}
.kick:after{content:'';flex:1;height:1px;background:linear-gradient(90deg,transparent,rgba(197,160,89,.8))}
.gt{background:linear-gradient(180deg,#F1E1B4 0%,#D2B070 55%,#A98440 100%);-webkit-background-clip:text;background-clip:text;color:transparent}
.ti{font-family:'KF','JN',serif;font-size:88px;line-height:1.45;margin:6px 0 10px}
.b{font-family:'JN',serif;font-size:53px;line-height:1.44;color:var(--cream)}.b+.b{margin-top:10px}
.q{font-family:'JN',serif;font-size:56px;line-height:1.5;color:var(--gold2)}
.qc{background:rgba(44,11,14,.55);border-right:4px solid var(--gold);padding:12px 32px 14px 24px;margin-top:14px}
.ref{display:inline-block;font-family:'JN',serif;font-size:42px;line-height:1.5;color:var(--gold);border:1px solid rgba(197,160,89,.7);padding:0 24px;margin-top:20px;background:rgba(44,11,14,.4)}
.wm{position:absolute;font-family:'KF','JN',serif;color:transparent;-webkit-text-stroke:2px rgba(197,160,89,.35);line-height:1;z-index:1}
.c{text-align:center}.c .kick{justify-content:center}.c .kick:before{content:'';flex:1;height:1px;background:linear-gradient(270deg,transparent,rgba(197,160,89,.8))}
.orn{display:flex;align-items:center;justify-content:center;gap:16px;margin:14px 0}.orn i{display:block;width:90px;height:1px;background:var(--gold)}.orn b{display:block;width:11px;height:11px;border:1.5px solid var(--gold);transform:rotate(45deg)}
"""
FR = ('<div class="frame"></div><div class="frame2"></div><div class="dm" style="top:24px;left:24px"></div><div class="dm" style="top:24px;right:24px"></div>'
      '<div class="dm" style="bottom:24px;left:24px"></div><div class="dm" style="bottom:24px;right:24px"></div><div class="ov vig" style="z-index:2"></div>')
ARROW = '<div class="swipe"><svg viewBox="0 0 70 24" fill="none" stroke="#C5A059" stroke-width="2"><path d="M70 12H4M14 2L3 12l11 10"/></svg></div>'

SKIP = {'layout','bg','pos','size','icon','handle'}
def urdu_digits(v, key=None):
    if isinstance(v, str): return v if key in SKIP else v.translate(str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹'))
    if isinstance(v, list): return [urdu_digits(x) for x in v]
    if isinstance(v, dict): return {k: urdu_digits(x, k) for k, x in v.items()}
    return v

def validate(slides):
    bad = False
    for i, d in enumerate(slides, 1):
        if d.get('layout') not in LAYOUTS: print(f'ERROR slide {i}: unknown layout {d.get("layout")!r}. Available: {", ".join(LAYOUTS)}'); bad = True
        if d.get('bg') and not pathlib.Path(d['bg']).exists(): print(f'ERROR slide {i}: bg not found {d["bg"]}'); bad = True
        text = ' '.join(str(v) for v in d.values() if isinstance(v, (str, list)))
        if len(text) > 700: print(f'WARN slide {i}: {len(text)} chars of text, probably too dense for one slide')
    missing = [k for k, f in FILES.items() if not (FD / f).exists()]
    if missing: print('WARN missing font files for codes:', ', '.join(missing))
    if bad: sys.exit(1)

def uri(p): return p if str(p).startswith(('file:', 'http', 'data:')) else pathlib.Path(p).resolve().as_uri()

def page(n, N, d, handle):
    d = dict(d)
    if d.get('bg'): d['bg'] = uri(d['bg'])
    css, body = LAYOUTS[d['layout']](d)
    body = body.replace('ﷺ', '<span class="sw">ﷺ</span>')
    dots = '<div class="dots">' + ''.join(f'<i class="{"on" if i == n else ""}"></i>' for i in range(1, N + 1)) + '</div>'
    last = n == N
    return (f'<!doctype html><html lang="ur" dir="rtl"><head><meta charset="utf-8"><style>{fontcss()}{BASE}{css}</style></head><body>'
            f'<div class="slide">{FR}{body}<div class="hdr"><span>{handle}</span><span>{n:02d} / {N:02d}</span></div><div class="hline"></div>{dots}{"" if last or d.get("no_arrow") else ARROW}</div></body></html>')

def main():
    spec = json.load(open(sys.argv[1])); out = pathlib.Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
    keep_png = '--png' in sys.argv
    only = None
    if '--only' in sys.argv: only = {int(x) for x in sys.argv[sys.argv.index('--only') + 1].split(',')}
    import shutil
    if not (out / 'spec.json').exists() or only is None: shutil.copy(sys.argv[1], out / 'spec.json')
    if spec.get('urdu_digits', True): spec = urdu_digits(spec)
    slides = spec['slides']; validate(slides); N = len(slides); handle = spec.get('handle', '@IBNESAED'); tmp = out / '_html'; tmp.mkdir(exist_ok=True)
    jpgs = []
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1080, 'height': 1350}, device_scale_factor=2)
        for i, d in enumerate(slides, 1):
            if only and i not in only:
                jpgs.append(Image.open(out / f'slide_{i:02d}.jpg').convert('RGB')); continue
            f = tmp / f's{i:02d}.html'; f.write_text(page(i, N, d, handle), encoding='utf-8')
            pg.goto(f.as_uri()); pg.evaluate('document.fonts.ready.then(()=>true)'); pg.wait_for_timeout(450)
            png = out / f'slide_{i:02d}.png'; pg.screenshot(path=str(png))
            im = Image.open(png).convert('RGB').resize((1080, 1350), Image.LANCZOS)
            jp = out / f'slide_{i:02d}.jpg'; im.save(jp, quality=90, optimize=True); jpgs.append(im)
            if not keep_png: png.unlink()
        b.close()
    jpgs[0].save(out / 'carousel.pdf', save_all=True, append_images=jpgs[1:], resolution=150)
    cols = min(5, N); rows = -(-N // cols); sh = Image.new('RGB', (360 * cols, 450 * rows), (44, 11, 14))
    for k, im in enumerate(jpgs): sh.paste(im.resize((360, 450)), ((k % cols) * 360, (k // cols) * 450))
    sh.save(out / 'sheet.jpg', quality=85)
    print('done', N, 'slides ->', out, '(view sheet.jpg once to QA)')
main()
