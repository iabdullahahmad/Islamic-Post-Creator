"""Layout library for islamic-post-creator. Each layout(d) -> (css, html). d = slide dict from the spec.
Text markup: [[gold highlight]]   {{UM:محمد}} = inline other font (UM,QB,KM,ZS,Z4,EG,KF,JK,JN)   \n = line break
"""
import re

def H(s):
    if s is None: return ''
    s = s.replace('\n', '<br>')
    s = re.sub(r'\[\[(.+?)\]\]', r'<span class="g2">\1</span>', s)
    s = re.sub(r'\{\{(\w+):(.+?)\}\}', r'<span style="font-family:\1,JN,serif;color:var(--gold2);font-size:1.15em">\2</span>', s)
    return s

def shade(top, mid, bot, c='44,11,14'):
    # top=(alpha_at_0, alpha_at_stop, stop%), mid=(alpha,stop%), bot=(alpha,stop%, alpha_at_100)
    return (f'<div class="ov" style="background:linear-gradient(180deg,rgba({c},{top[0]}) 0,rgba({c},{top[1]}) {top[2]}%,'
            f'rgba({c},{mid[0]}) {mid[1]}%,rgba({c},{bot[0]}) {bot[1]}%,rgba({c},{bot[2]}) 100%)"></div>')

def blk(inner, pos='top:140px', cls=''):
    return f'<div class="abs {cls}" style="{pos};right:100px;left:100px;z-index:5">{inner}</div>'

def bgd(d, pos='50% 50%', size='cover'):
    return f'<div class="bg" style="background-image:url({d["bg"]});background-position:{d.get("pos",pos)};background-size:{d.get("size",size)}"></div>' if d.get('bg') else ''

def kick(d): return f'<div class="kick">{H(d["kicker"])}</div>' if d.get('kicker') else ''
def ref(d): return f'<div class="ref">{H(d["ref"])}</div>' if d.get('ref') else ''
def paras(v):
    if isinstance(v, str): v = [v]
    return ''.join(f'<div class="b">{H(x)}</div>' for x in (v or []))
def title(d, size=None, k='title'):
    st = f' style="font-size:{size}px"' if size else ''
    return f'<div class="ti gt"{st}>{H(d[k])}</div>' if d.get(k) else ''
def wm(d, size=520, top=300):
    return f'<div class="wm" style="font-size:{size}px;top:{top}px;left:40px">{H(d["wm"])}</div>' if d.get('wm') else ''
def quote(d):
    return f'<div class="qc"><div class="q">{H(d["quote"])}</div></div>' if d.get('quote') else ''

# 1 ---------------------------------------------------------------- cover_stack
def cover_stack(d):
    css = ".t1{font-family:'KF','JN',serif;font-size:96px;line-height:1.5;color:var(--cream)}.t2{font-family:'JK',serif;font-size:104px;line-height:1.55}.sub{font-family:'JN',serif;font-size:56px;line-height:1.5;color:var(--cream)}.chip{display:inline-block;font-family:'KF','JN',serif;font-size:44px;color:var(--obs);background:var(--gold);padding:2px 30px;margin-top:14px}"
    h = bgd(d, '50% 100%') + shade((.9,.55,32),(0,50),(0,66,.93),'44,11,14')
    h += blk(f'<div class="t1">{H(d["line1"])}</div><div class="t2 gt">{H(d["line2"])}</div>', 'top:150px')
    h += blk(f'<div class="orn" style="justify-content:flex-start;margin:0 0 18px"><b></b><i></i></div><div class="sub">{H(d.get("sub",""))}</div>' + (f'<div class="chip">{H(d["chip"])}</div>' if d.get('chip') else ''), 'bottom:165px')
    return css, h

# 2 ---------------------------------------------------------------- top_text
def top_text(d):
    h = bgd(d, '50% 100%') + shade((.94,.8,38),(0,56),(0,74,.5),'38,10,16') + wm(d)
    inner = kick(d) + title(d, 76) + paras(d.get('body')) + quote(d)
    h += blk(inner, 'top:140px') + (blk(ref(d), 'bottom:140px') if d.get('ref') else '')
    return '', h

# 3 ---------------------------------------------------------------- bottom_card
def bottom_card(d):
    h = bgd(d, '50% 30%') + shade((.88,.5,24),(0,40),(0,56,.95))
    h += blk(kick(d) + title(d, 80), 'top:140px')
    h += blk(paras(d.get('body')) + quote(d) + ref(d), 'bottom:130px')
    return '', h

# 4 ---------------------------------------------------------------- editorial_split
def editorial_split(d):
    h = bgd(d, '50% 150px', '1180px auto') + shade((.9,.2,14),(0,34),(0,58,.96)) + wm(d, 420, 150)
    h += blk(kick(d) + title(d, 88) + paras(d.get('body')) + ref(d), 'bottom:130px')
    return '', h

# 5 ---------------------------------------------------------------- hero_swash
def hero_swash(d):
    css = ".hero{font-family:'ZS','Z4',serif;font-weight:300;font-size:%spx;line-height:1.2;text-align:center}" % d.get('swash_size', 260)
    h = bgd(d, '50% 20%') + shade((.9,.3,20),(0,36),(0,52,.95))
    h += blk(kick(d) + title(d, 88), 'top:140px')
    h += f'<div class="abs hero gt" style="top:{d.get("swash_top",470)}px;left:0;right:0;z-index:4;filter:drop-shadow(0 6px 24px rgba(0,0,0,.8))">{H(d["swash"])}</div>'
    h += blk(paras(d.get('body')) + ref(d), 'bottom:130px')
    return css, h

# 6 ---------------------------------------------------------------- center_card
def center_card(d):
    css = ".card{background:rgba(44,11,14,.8);border:1px solid var(--gold);padding:34px 44px 30px;outline:1px solid rgba(197,160,89,.3);outline-offset:8px}"
    h = bgd(d, '50% 40%') + shade((.55,.2,26),(0,44),(0,60,.5),'44,11,14')
    h += blk(f'<div class="card c">{kick(d)}{title(d, 82)}<div class="orn"><i></i><b></b><i></i></div>{paras(d.get("body"))}{ref(d)}</div>', f'top:{d.get("top",300)}px')
    return css, h

# 7 ---------------------------------------------------------------- timeline
def timeline(d):
    css = ".tl{position:relative;padding-right:70px}.tl:before{content:'';position:absolute;right:20px;top:20px;bottom:30px;width:2px;background:linear-gradient(var(--gold),rgba(197,160,89,.2))}.it{position:relative;font-family:'JN',serif;font-size:52px;line-height:1.5;color:var(--cream);margin-bottom:18px}.it:before{content:'';position:absolute;right:-60px;top:24px;width:22px;height:22px;border-radius:50%;background:var(--gold);box-shadow:0 0 0 6px rgba(197,160,89,.25)}"
    h = bgd(d, '50% 100%') + shade((.85,.35,30),(.05,44),(.55,60,.96))
    h += blk(kick(d) + title(d, 88), 'top:140px')
    h += blk('<div class="tl">' + ''.join(f'<div class="it">{H(x)}</div>' for x in d['items']) + '</div>' + ref(d), 'bottom:130px')
    return css, h

# 8 ---------------------------------------------------------------- numbered_list
def numbered_list(d):
    css = ".row{display:flex;gap:24px;align-items:flex-start;border-top:1px solid rgba(197,160,89,.45);padding:12px 0}.n{font-family:'JN',serif;font-size:84px;line-height:1.1;color:transparent;-webkit-text-stroke:2px var(--gold);min-width:74px;text-align:center}.t{font-family:'JN',serif;font-size:52px;line-height:1.5;color:var(--cream)}"
    nums = '۱۲۳۴۵۶۷۸۹'
    h = bgd(d, '50% 50%') + shade((.85,.5,28),(.05,44),(.6,58,.96),'40,12,14')
    h += blk(kick(d) + title(d, 88), 'top:140px')
    h += blk(''.join(f'<div class="row"><div class="n">{nums[i]}</div><div class="t">{H(x)}</div></div>' for i, x in enumerate(d['items'])) + ref(d), 'bottom:130px')
    return css, h

# 9 ---------------------------------------------------------------- big_number
def big_number(d):
    css = ".num{font-family:'KF','JN',serif;font-size:640px;line-height:1;text-align:center;filter:drop-shadow(0 10px 40px rgba(0,0,0,.7))}.cap{font-family:'JK',serif;font-size:84px;line-height:1.5;text-align:center;color:var(--cream)}"
    h = bgd(d, '50% 50%') + shade((.75,.45,40),(.35,60),(.8,74,.95))
    h += blk(kick(d), 'top:140px')
    h += f'<div class="abs num gt" style="top:{d.get("num_top",190)}px;left:0;right:0;z-index:4">{H(d["number"])}</div>'
    h += blk(f'<div class="cap gt">{H(d.get("caption",""))}</div>' + paras(d.get('body')) + ref(d), 'bottom:130px', 'c')
    return css, h

# 10 --------------------------------------------------------------- quote_poster
def quote_poster(d):
    css = ".qm{font-family:'JK',serif;font-size:420px;line-height:.6;color:rgba(197,160,89,.35);text-align:right}.big{font-family:'JK',serif;font-size:96px;line-height:1.7;color:var(--cream);text-shadow:0 4px 30px rgba(0,0,0,.8)}.by{font-family:'KF','JN',serif;font-size:46px;color:var(--gold);margin-top:20px}"
    h = bgd(d, '50% 50%') + shade((.7,.7,50),(.7,60),(.8,80,.9))
    h += blk('<div class="qm">“</div><div class="big">' + H(d['quote']) + '</div>' + (f'<div class="by">— {H(d["by"])}</div>' if d.get('by') else '') + ref(d), 'top:260px')
    return css, h

# 11 --------------------------------------------------------------- arch_window
def arch_window(d):
    css = ".arch{position:absolute;left:150px;right:150px;top:150px;height:640px;border-radius:390px 390px 0 0;border:2px solid var(--gold);outline:1px solid rgba(197,160,89,.35);outline-offset:10px;background-size:cover;background-position:POS;z-index:3;box-shadow:0 20px 60px rgba(0,0,0,.6)}.pat{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 20%,rgba(197,160,89,.14),transparent 60%),#2C0B0E}".replace('POS', d.get('pos', '50% 50%'))
    h = '<div class="pat"></div>' + f'<div class="arch" style="background-image:url({d["bg"]})"></div>'
    h += blk(kick(d) + title(d, 84) + paras(d.get('body')) + ref(d), 'top:830px')
    return css, h

# 12 --------------------------------------------------------------- image_text_hook
def image_text_hook(d):
    css = ".word{font-family:'KF','JN',serif;font-size:%spx;line-height:1.25;text-align:center;background-image:url(%s);background-size:cover;background-position:50%% 50%%;-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-stroke:3px rgba(197,160,89,.9);filter:drop-shadow(0 10px 40px rgba(0,0,0,.7))}.sub2{font-family:'JK',serif;font-size:64px;line-height:1.6;text-align:center;color:var(--cream)}" % (d.get('word_size', 210), d['bg'])
    h = f'<div class="bg" style="background-image:url({d["bg"]});background-size:cover;background-position:50% 50%;filter:blur(14px) brightness(.5);transform:scale(1.1)"></div>'
    h += blk(kick(d), 'top:140px')
    h += f'<div class="abs word" style="top:{d.get("word_top",300)}px;left:60px;right:60px;z-index:4">{H(d["word"])}</div>'
    h += blk(f'<div class="sub2">{H(d.get("sub",""))}</div><div class="orn"><i></i><b></b><i></i></div>', 'bottom:190px', 'c')
    return css, h

# 13 --------------------------------------------------------------- diptych
def diptych(d):
    css = ".dp{display:flex;gap:0}.dc{flex:1;padding:0 26px}.dc+.dc{border-right:1px solid rgba(197,160,89,.6)}.dl{font-family:'KF','JN',serif;font-size:50px;line-height:1.5;color:var(--gold);border-bottom:1px solid rgba(197,160,89,.6);padding-bottom:6px;margin-bottom:12px}.dt{font-family:'JN',serif;font-size:50px;line-height:1.5;color:var(--cream)}"
    h = bgd(d, '50% 40%') + shade((.88,.5,26),(.3,50),(.88,64,.95))
    h += blk(kick(d) + title(d, 88), 'top:140px')
    cols = ''.join(f'<div class="dc"><div class="dl">{H(c["label"])}</div><div class="dt">{H(c["text"])}</div></div>' for c in d['cols'])
    h += blk(f'<div class="dp">{cols}</div>' + ref(d), 'bottom:130px')
    return css, h

# 14 --------------------------------------------------------------- ivory_text (light rhythm breaker)
def ivory_text(d):
    css = ".paper{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 30%,#EFE9DD,#E5DFD3)}.fade{position:absolute;inset:0;opacity:.14;mix-blend-mode:multiply;background-size:cover;background-position:50% 50%}.vig{display:none}.frame{border-color:rgba(122,92,40,.7)!important}.frame2{border-color:rgba(122,92,40,.3)!important}.dm{background:#7A5C28!important}.hdr{color:#7A5C28!important}.hline{background:linear-gradient(90deg,transparent,rgba(122,92,40,.6),transparent)!important}.kick{color:#7A5C28}.kick:after,.c .kick:before{background:linear-gradient(90deg,transparent,rgba(122,92,40,.8))!important}.gt{background:linear-gradient(180deg,#b8862f,#5E4318)!important;-webkit-background-clip:text!important;background-clip:text!important;color:transparent!important}.b{color:#2C0B0E!important}.g2{color:#4A0E17!important}.q{color:#4A0E17!important}.qc{background:rgba(122,92,40,.08)!important;border-right-color:#7A5C28!important}.ref{color:#5E4318!important;border-color:rgba(122,92,40,.7)!important;background:transparent!important}"
    h = '<div class="paper"></div>' + (f'<div class="fade" style="background-image:url({d["bg"]})"></div>' if d.get('bg') else '')
    h += blk(kick(d) + title(d, 92) + paras(d.get('body')) + quote(d) + ref(d), 'top:230px')
    return css, h

# 15 --------------------------------------------------------------- cta_outro
ICONS = {
 'comment': '<path d="M8 10h32v22H22l-9 8v-8H8z"/>',
 'save': '<path d="M12 6h24v36l-12-9-12 9z"/>',
 'share': '<path d="M8 26l32-16-8 28-10-9-8 6-2-10z"/>',
 'like': '<path d="M24 40S6 29 6 17a9 9 0 0118-3 9 9 0 0118 3c0 12-18 23-18 23z"/>',
}
def cta_outro(d):
    css = ".cta{display:flex;align-items:center;gap:22px;border:1px solid var(--gold);background:rgba(44,11,14,.6);padding:4px 26px;margin-top:10px;font-family:'JN',serif;font-size:42px;line-height:1.5;color:var(--cream)}.cta svg{width:50px;height:50px;flex:none}.hd{font-family:'KM',sans-serif;letter-spacing:.3em;color:var(--gold);font-size:34px;text-align:center;direction:ltr;margin-top:18px}"
    h = bgd(d, '50% 40%') + shade((.8,.35,30),(0,40),(.8,54,.96))
    h += blk(kick(d) + title(d, 80), 'top:140px', 'c')
    ctas = ''.join(f'<div class="cta"><svg viewBox="0 0 48 48" fill="none" stroke="#C5A059" stroke-width="2.5">{ICONS.get(c.get("icon","comment"))}</svg><div>{H(c["text"])}</div></div>' for c in d.get('ctas', []))
    h += blk(f'<div class="b c" style="font-size:46px">{H(d.get("body",""))}</div>{ctas}<div class="hd">{d.get("handle","@IBNESAED")}</div>', 'bottom:100px')
    return css, h

LAYOUTS = {f.__name__: f for f in (cover_stack, top_text, bottom_card, editorial_split, hero_swash, center_card, timeline,
           numbered_list, big_number, quote_poster, arch_window, image_text_hook, diptych, ivory_text, cta_outro)}
