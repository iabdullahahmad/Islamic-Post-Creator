#!/usr/bin/env python3
"""Shrink big images before building (saves credits + build time; slides are 1080 wide anyway).
python3 prep_images.py IN_DIR_OR_FILES... OUT_DIR   -> OUT_DIR/<same name>.jpg, max width 1400px, quality 90"""
import sys, pathlib
from PIL import Image
*ins, out = sys.argv[1:]
out = pathlib.Path(out); out.mkdir(parents=True, exist_ok=True)
files = []
for i in ins:
    p = pathlib.Path(i); files += sorted(p.glob('*')) if p.is_dir() else [p]
for f in files:
    if f.suffix.lower() not in ('.jpg', '.jpeg', '.png', '.webp'): continue
    im = Image.open(f).convert('RGB')
    if im.width > 1400: im = im.resize((1400, round(im.height * 1400 / im.width)), Image.LANCZOS)
    im.save(out / (f.stem + '.jpg'), quality=90, optimize=True); print(f.name, '->', im.size)
