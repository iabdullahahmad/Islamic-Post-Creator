#!/usr/bin/env python3
"""
Render an HTML file to a PNG image using headless Chromium (Playwright).
Waits for web fonts to load before capturing, so Arabic/Urdu fonts render correctly.

Usage:
    python3 render_slide.py input.html output.png --width 1080 --height 1350
    python3 render_slide.py input.html output.png --width 1080 --height 1080 --scale 2
"""

import argparse
import pathlib
import sys

from playwright.sync_api import sync_playwright


def render(input_path: str, output_path: str, width: int, height: int, scale: float, full_page: bool):
    input_path = pathlib.Path(input_path).resolve()
    if not input_path.exists():
        print(f"Error: input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    url = input_path.as_uri()

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(
            viewport={"width": width, "height": height},
            device_scale_factor=scale,
        )
        page.goto(url)
        # Wait for web fonts (Amiri, Noto Nastaliq Urdu, etc.) to finish loading
        # before capturing -- otherwise Arabic/Urdu text falls back to a
        # system font for the screenshot.
        page.evaluate("document.fonts.ready.then(() => true)")
        page.wait_for_timeout(300)  # small buffer for webfont paint/layout settle

        page.screenshot(path=output_path, full_page=full_page)
        browser.close()

    print(f"Rendered: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Render an HTML file to PNG via headless Chromium")
    parser.add_argument("input", help="Path to input HTML file")
    parser.add_argument("output", help="Path to output PNG file")
    parser.add_argument("--width", type=int, default=1080, help="Viewport width in px (default 1080)")
    parser.add_argument("--height", type=int, default=1350, help="Viewport height in px (default 1350, IG 4:5)")
    parser.add_argument("--scale", type=float, default=2.0, help="Device scale factor for crisp export (default 2x)")
    parser.add_argument("--full-page", action="store_true", help="Capture full scrollable page instead of fixed viewport")
    args = parser.parse_args()

    render(args.input, args.output, args.width, args.height, args.scale, args.full_page)
