# Layout library (scripts/layouts.py) — one-shot build
Build the whole carousel with ONE command, no per-slide HTML:
`python3 scripts/build_carousel.py spec.json OUT_DIR`  → OUT_DIR/slide_01.jpg … + carousel.pdf (1080x1350, JPG ~250KB, light for any device).
Spec = `{"handle":"@IBNESAED","slides":[{"layout":"<name>","bg":"/abs/path.jpg", ...fields}]}`. See `templates/example_spec.json` (all 15 layouts).
Text markup: `[[gold highlight]]`, `{{UM:محمد}}` (inline font: UM/QB/KM/ZS/Z4/EG), `\n` line break. Digits: write Urdu numerals (۶ ۱۲ ۲۵).
Common fields: kicker (small gold label), title, body (string or list of paragraphs), quote, ref (حوالہ chip), wm (giant outlined numeral watermark), pos (background-position), no_arrow.
Every slide gets: gold double frame + corner diamonds, @handle + counter, progress dots, swipe arrow (not on last slide).

| layout | fields | best for / why it stops the scroll |
|---|---|---|
| cover_stack | line1, line2, sub, chip | Cover: 2-tier title (cream + gold gradient), age/part chip |
| image_text_hook | word, sub, kicker, word_size | HOOK: giant word filled with the photo. Question/one-word cover, strongest thumb-stopper |
| top_text | kicker,title,body,quote,ref,wm | Story slide, picture stays visible below the text |
| bottom_card | kicker,title,body,quote,ref | Title top, quote card bottom; photo with a subject in the middle |
| quote_poster | quote, by, ref | Minimal: huge quote on dimmed photo. Share/save-worthy line |
| big_number | number, caption, kicker, body | Stat slide: giant gold numeral (age, count, year) |
| editorial_split | kicker,title,body(list),ref,wm | Long text: photo on top fading into a solid text base |
| hero_swash | swash, kicker,title,body | Giant Arabic swash word (Zain Swashes) over photo, e.g. الأمين |
| center_card | kicker,title,body,ref | Framed centered card over busy photos (patterns, roses) |
| numbered_list | kicker,title,items[],ref | 2-4 steps/points |
| timeline | kicker,title,items[],ref | Journey/sequence of events |
| diptych | kicker,title,cols[{label,text}],ref | Before/after, two moments, two witnesses |
| arch_window | kicker,title,body,ref,bg | Photo inside a mihrab-style arch; elegant, calm |
| ivory_text | kicker,title,body,quote,ref | LIGHT paper slide: rhythm break, reflection/dua text |
| cta_outro | title, body, ctas[{icon,text}], handle | Last slide: comment/save/share rows (icons: comment, save, share, like) |

## Retention playbook (what makes viewers stay and swipe)
1. Slide 1 = hook: image_text_hook or cover_stack with a curiosity line or question, never just a title.
2. Alternate dense and airy slides (e.g. big_number / quote_poster between text slides); insert ONE ivory_text slide mid-carousel to break the dark rhythm.
3. One idea per slide; max ~45 words body. Put the emotional line in gold highlight [[...]].
4. Keep the swipe arrow + progress dots (already automatic) so viewers see how far they are.
5. End with cta_outro: a concrete action (comment درود, save, share to 3 friends).
6. Use the photo's subject: pick pos/shade so the text never covers the main subject.
