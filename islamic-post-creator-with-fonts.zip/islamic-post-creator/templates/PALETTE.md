# IbneSaed palette
| Name | Hex | Token | Use |
|---|---|---|---|
| Deep Velvet Maroon | #2C0B0E | --obs | slide background, photo shading, ink on ivory slides |
| Imperial Burgundy | #4A0E17 | --mar | secondary accent, quote bars, highlights on ivory slides |
| Brushed Antique Gold | #C5A059 | --gold | frame, kicker, chips, gradient titles (#F1E1B4 > #D2B070 > #A98440) |
| Gold highlight (derived) | #E3CB92 | --gold2 | [[highlight]] words in body |
| Warm Alabaster | #E5DFD3 | --cream | body text, ivory paper |
